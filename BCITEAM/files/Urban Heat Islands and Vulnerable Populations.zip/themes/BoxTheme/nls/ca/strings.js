define({
  "_themeLabel": "Tema Quadre",
  "_layout_default": "Disseny per defecte",
  "_layout_top": "Disseny superior"
});