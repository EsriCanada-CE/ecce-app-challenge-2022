define({
  "_themeLabel": "Bokstema",
  "_layout_default": "Standardoppsett",
  "_layout_top": "Topp-oppsett"
});