define({
  "_themeLabel": "Tema Caixa",
  "_layout_default": "Layout predefinido",
  "_layout_top": "Layout do topo"
});