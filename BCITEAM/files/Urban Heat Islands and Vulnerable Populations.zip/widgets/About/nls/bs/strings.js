define({
  "productVersion": "Verzija proizvoda: ",
  "kernelVersion": "Verzija jezgre sustava: ",
  "_widgetLabel": "Informacije"
});