define({
  "productVersion": "Produktversion: ",
  "kernelVersion": "Kerneversion: ",
  "_widgetLabel": "Om"
});