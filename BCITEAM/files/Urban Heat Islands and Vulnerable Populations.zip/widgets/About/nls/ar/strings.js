define({
  "productVersion": "إصدار المنتج: ",
  "kernelVersion": "إصدار Kernel: ",
  "_widgetLabel": "نبذة عن"
});